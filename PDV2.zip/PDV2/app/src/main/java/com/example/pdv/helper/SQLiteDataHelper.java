package com.example.pdv.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteDataHelper extends SQLiteOpenHelper {

    public SQLiteDataHelper(@Nullable Context context,
                            @Nullable String name,
                            @Nullable SQLiteDatabase.CursorFactory factory,
                            int version) {
        super(context, name, factory, version);
    }

    /***
     * Método é executado uma unica vez quando o aplicativo é instalado
     * é responsável por executar os scripts da criação das tabelas
     * @param sqLiteDatabase : base de dados que irá se criar as tabelas
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE VENDAS (COD_PRODUTO INTEGER, PRODUTO VARCHAR(100),QTDE INTEGER, VALOR INTEGER, COD_VENDEDOR INTEGER , NOME_VENDEDOR VARCHAR(100), DATA_VENDA VARCHAR(10), NOME_CLIENTE VARCHAR(100), CPF_CNPJ INTEGER)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }
}
