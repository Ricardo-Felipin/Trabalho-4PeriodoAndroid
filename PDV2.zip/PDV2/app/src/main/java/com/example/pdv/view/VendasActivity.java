package com.example.pdv.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pdv.R;
import com.example.pdv.adapter.VendasListAdapter;
import com.example.pdv.controller.VendasController;
import com.example.pdv.model.Vendas;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class VendasActivity extends AppCompatActivity {

    private FloatingActionButton btCadastroVenda;
    private AlertDialog dialog;
    private VendasController controller;
    private EditText edCodProduto;

    private EditText edProduto;

    private EditText edQtde;

    private EditText edValor;

    private EditText edCodVendedor;

    private EditText edVendedor;

    private EditText edDataVenda;

    private EditText edCliente;

    private EditText edCpf;

    private View viewAlert;
    private RecyclerView rvVendas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendas);

        controller = new VendasController(this);
        rvVendas = findViewById(R.id.rvVendas);
        btCadastroVenda = findViewById(R.id.btCadastroVenda);
        btCadastroVenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastro();
            }
        });

        AtualizarListaVendas();
    }

    private void abrirCadastro() {
        //Carregando o arquivo xml do layout
        viewAlert = getLayoutInflater()
                .inflate(R.layout.dialog_cadastro_vendas, null);

        edCodProduto = viewAlert.findViewById(R.id.edCodProduto);
        edProduto = viewAlert.findViewById(R.id.edProduto);
        edQtde = viewAlert.findViewById(R.id.edQtde);
        edValor = viewAlert.findViewById(R.id.edValor);
        edCodVendedor = viewAlert.findViewById(R.id.edCodVendedor);
        edVendedor = viewAlert.findViewById(R.id.edVendedor);
        edDataVenda = viewAlert.findViewById(R.id.edDataVenda);
        edCliente = viewAlert.findViewById(R.id.edCliente);
        edCpf = viewAlert.findViewById(R.id.edCpf);

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cadastrar Venda"); //Adicionando título ao popup
        builder.setView(viewAlert); //Setando o layout
        builder.setCancelable(false); //não deixa fechar o popup se clicar fora dele

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialog.dismiss();
            }
        });
        builder.setPositiveButton("Salvar", null);
        dialog = builder.create();
        //Adicionando ação ao botão salvar após criação da tela
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button bt = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        salvarDados();
                    }
                });
            }
        });
        dialog.show();

    }

    public void salvarDados(){
        String retorno = controller.salvarVendas(edCodProduto.getText().toString(),
                                                    edProduto.getText().toString(),
                                                    edQtde.getText().toString());
        if(retorno != null){
            if(retorno.contains("RA")){
                edCodProduto.setError(retorno);
                edCodProduto.requestFocus();
            }
            if(retorno.contains("NOME")){
                edProduto.setError(retorno);
                edProduto.requestFocus();
            }
        }else{
            Toast.makeText(this,
                    "Aluno salvo com sucesso!",
                    Toast.LENGTH_LONG).show();

            dialog.dismiss();
            AtualizarListaVendas();
        }
    }

    /**
     * Método cria e atualiza a lista de alunos
     */
    private void AtualizarListaVendas(){
        ArrayList<Vendas> listaVendas = controller.retornarVendas();
        VendasListAdapter adapter = new VendasListAdapter(listaVendas, this);
        rvVendas.setLayoutManager(new LinearLayoutManager(this));
        rvVendas.setAdapter(adapter);
    }
}
