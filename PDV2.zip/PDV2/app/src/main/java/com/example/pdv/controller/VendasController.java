package com.example.pdv.controller;

import android.content.Context;

import com.example.pdv.dao.VendasDao;
import com.example.pdv.model.Vendas;

import java.util.ArrayList;

public class VendasController {

    private Context context;

    public VendasController(Context context) {
        this.context = context;
    }

    public String salvarVendas(String codproduto, String produto, String qtde){
        try{
            if(codproduto.equals("") || codproduto.isEmpty()){
                return "Informe o RA do Aluno!";
            }
            if(produto.equals("") || produto.isEmpty()){
                return "Informe o NOME do Aluno!";
            }
            if(qtde.equals("") || qtde.isEmpty()){
                return "Informe o QTDE do Aluno!";
            }

            Vendas vendas = VendasDao.getInstancia(context)
                    .getById(Integer.parseInt(codproduto));
            if(vendas != null){
                return "O RA ("+codproduto+") já está cadastrado!";
            }else{
                vendas = new Vendas();
                vendas.setCodProduto(Integer.parseInt(codproduto));
                vendas.setProduto(produto);
                vendas.setQtde(Integer.parseInt(qtde));

                VendasDao.getInstancia(context).insert(vendas);
            }

        }catch (Exception ex){
            return "Erro ao Gravar Aluno.";
        }
        return null;
    }

    /**
     * Retorna todos os alunos cadastrados no banco
     * @return
     */
    public ArrayList<Vendas> retornarVendas(){
        return VendasDao.getInstancia(context).getAll();
    }

}
