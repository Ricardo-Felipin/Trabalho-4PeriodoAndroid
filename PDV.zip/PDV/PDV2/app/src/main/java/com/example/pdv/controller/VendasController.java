package com.example.pdv.controller;

import android.content.Context;

import com.example.pdv.dao.VendasDao;
import com.example.pdv.model.Vendas;

import java.util.ArrayList;

public class VendasController {

    private Context context;

    public VendasController(Context context) {
        this.context = context;
    }

    public String salvarVendas(String codproduto, String produto, String qtde, String valor, String vendedor, String datavenda, String cliente, String cpf){
        try{
            if(codproduto.equals("") || codproduto.isEmpty()){
                return "Informe o Código do Pedido!";
            }
            if(produto.equals("") || produto.isEmpty()){
                return "Informe o Produto!";
            }
            if(qtde.equals("") || qtde.isEmpty()){
                return "Informe a Quantidade Vendida!";
            }
            if(valor.equals("") || valor.isEmpty()){
                return "Informe o Valor Vendido!";
            }
            if(vendedor.equals("") || vendedor.isEmpty()){
                return "Informe o Vendedor!";
            }
            if(datavenda.equals("") || datavenda.isEmpty()){
                return "Informe a Data da Venda!";
            }
            if(cliente.equals("") || cliente.isEmpty()){
                return "Informe o Nome do Cliente!";
            }
            if(cpf.equals("") || cpf.isEmpty()){
                return "Informe o CPF/CNPJ do Cliente";
            }

            Vendas vendas = VendasDao.getInstancia(context)
                    .getById(Integer.parseInt(codproduto));
            if(vendas != null){
                return "O Pedido ("+codproduto+") já foi cadastrado!";
            }else{
                vendas = new Vendas();
                vendas.setCodProduto(Integer.parseInt(codproduto));
                vendas.setProduto(produto);
                vendas.setQtde(Integer.parseInt(qtde));
                vendas.setValor(Integer.parseInt(valor));
                vendas.setVendedor(vendedor);
                vendas.setDataVenda(datavenda);
                vendas.setCliente(cliente);
                vendas.setCpf(Integer.parseInt(cpf));

                VendasDao.getInstancia(context).insert(vendas);
            }

        }catch (Exception ex){
            return "Erro ao Gravar Pedido.";
        }
        return null;
    }

    public ArrayList<Vendas> retornarVendas(){
        return VendasDao.getInstancia(context).getAll();
    }

}
