package com.example.pdv.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pdv.R;
import com.example.pdv.model.Vendas;

import java.util.ArrayList;

public class VendasListAdapter extends
        RecyclerView.Adapter<VendasListAdapter.ViewHolder>{

        private ArrayList<Vendas> listaVendas;
        private Context context;

    public VendasListAdapter(ArrayList<Vendas> listaVendas, Context context) {
            this.listaVendas = listaVendas;
            this.context = context;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            LayoutInflater inflater = LayoutInflater.from(parent.getContext());

            View listItem = inflater.inflate(R.layout.item_list_vendas,parent, false);

            return new ViewHolder(listItem);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Vendas vendaSelecionada = listaVendas.get(position);
            holder.tvCodProduto.setText(String.valueOf(vendaSelecionada.getCodProduto()));
            holder.tvProduto.setText(vendaSelecionada.getProduto());
            holder.tvQtde.setText(String.valueOf(vendaSelecionada.getQtde()));
            holder.tvValor.setText(String.valueOf(vendaSelecionada.getValor()));
            holder.tvNomeVendedor.setText(vendaSelecionada.getVendedor());
            holder.tvDataVenda.setText(vendaSelecionada.getDataVenda());
            holder.tvNomeCliente.setText(vendaSelecionada.getCliente());
            holder.tvCpfCliente.setText(vendaSelecionada.getCpf());

        }

        @Override
        public int getItemCount() {
            return this.listaVendas.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{

            public TextView tvCodProduto;
            public TextView tvProduto;
            public TextView tvQtde;
            public TextView tvValor;
            public TextView tvNomeVendedor;
            public TextView tvDataVenda;
            public TextView tvNomeCliente;
            public TextView tvCpfCliente;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                this.tvCodProduto = itemView.findViewById(R.id.tvCodProduto);
                this.tvProduto = itemView.findViewById(R.id.tvProduto);
                this.tvQtde = itemView.findViewById(R.id.tvQtde);
                this.tvValor = itemView.findViewById(R.id.tvValor);
                this.tvNomeVendedor = itemView.findViewById(R.id.tvNomeVendedor);
                this.tvDataVenda = itemView.findViewById(R.id.tvDataVenda);
                this.tvNomeCliente = itemView.findViewById(R.id.tvNomeCliente);
                this.tvCpfCliente = itemView.findViewById(R.id.tvCpfCliente);
            }
        }


    }
