package com.example.pdv.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.pdv.R;
import com.example.pdv.view.MainActivity;
import com.example.pdv.view.VendasActivity;

public class EscolhaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);
    }

    public void abrirCadastroVendas(View view) {
        Intent intent = new Intent(EscolhaActivity.this,
                VendasActivity.class);

        startActivity(intent);

    }

    public void abrirCadastroPagamento(View view) {
        Intent intent = new Intent(EscolhaActivity.this,
                PagamentoActivity.class);

        startActivity(intent);

    }

}