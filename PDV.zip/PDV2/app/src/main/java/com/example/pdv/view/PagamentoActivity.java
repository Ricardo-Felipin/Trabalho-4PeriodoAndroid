package com.example.pdv.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.pdv.R;

public class PagamentoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento);
    }
}