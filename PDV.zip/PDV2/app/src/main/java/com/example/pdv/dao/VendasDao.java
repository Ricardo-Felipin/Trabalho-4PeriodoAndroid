package com.example.pdv.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.pdv.helper.SQLiteDataHelper;
import com.example.pdv.model.Vendas;

import java.util.ArrayList;

public class VendasDao implements IGenericDao<Vendas>{

    //Variavel responsavel por abrir conexão com a BD
    private SQLiteOpenHelper openHelper;

    //Base de Dados
    private SQLiteDatabase baseDados;

    //nome das colunas da tabela;
    private String[]colunas = {"COD_PRODUTO", "PRODUTO", "QTDE", "VALOR", "NOME_VENDEDOR", "DATA_VENDA", "NOME_CLIENTE", "CPF_CNPJ"};
    //nome da tabela
    private String tabela = "VENDAS";

    //Contexto (view)
    private Context context;

    private static VendasDao instancia;

    public static VendasDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new VendasDao(context);
        }else{
            return instancia;
        }
    }

    private VendasDao(Context context){
        this.context = context;

        //Abrir a conexão com a base de dados
        openHelper = new SQLiteDataHelper(this.context,
                "BDVENDAS", null, 1);

        //instanciando a base de dados
        baseDados = openHelper.getWritableDatabase();


    }

    @Override
    public long insert(Vendas obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getCodProduto());
            valores.put(colunas[1], "Produto: " + obj.getProduto());
            valores.put(colunas[2], obj.getQtde());
            valores.put(colunas[3], obj.getValor());
            valores.put(colunas[4], "Vendedor: " + obj.getVendedor());
            valores.put(colunas[5], "Data Venda: " + obj.getDataVenda());
            valores.put(colunas[6], "Cliente: " + obj.getCliente());
            valores.put(colunas[7], "CPF: " + obj.getCpf());


            return baseDados.insert(tabela, null, valores);

        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: VendasDao.insert() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Vendas obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getProduto());
            valores.put(colunas[2], obj.getQtde());
            valores.put(colunas[3], obj.getValor());
            valores.put(colunas[4], obj.getVendedor());
            valores.put(colunas[5], obj.getDataVenda());
            valores.put(colunas[6], obj.getCliente());
            valores.put(colunas[7], obj.getCpf());

            String[]identificador = {String.valueOf(obj.getCodProduto())};

            return baseDados.update(tabela,  valores,
                    colunas[0]+"= ?", identificador);

        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: VendasDao.update() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Vendas obj) {
        try{
            String[]identificador = {String.valueOf(obj.getCodProduto())};

            return baseDados.delete(tabela,
                    colunas[0]+"= ?", identificador);
        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: VendasDao.delete() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Vendas> getAll() {
        ArrayList<Vendas> lista = new ArrayList<>();
        try{
            Cursor cursor = baseDados.query(tabela,
                    colunas, null,
                    null, null,
                    null, colunas[0]+" desc");

            if(cursor.moveToFirst()){
                do{
                    Vendas vendas = new Vendas();
                    vendas.setCodProduto(cursor.getInt(0));
                    vendas.setProduto(cursor.getString(1));
                    vendas.setQtde(cursor.getInt(2));
                    vendas.setValor(cursor.getInt(3));
                    vendas.setVendedor(cursor.getString(4));
                    vendas.setDataVenda(cursor.getString(5));
                    vendas.setCliente(cursor.getString(6));
                    vendas.setCpf(cursor.getString(7));

                    lista.add(vendas);

                }while (cursor.moveToNext());
            }

        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: VendasDao.getAll() "+ex.getMessage());
        }

        return lista;
    }

    @Override
    public Vendas getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = baseDados.query(tabela, colunas,
                    colunas[0]+"= ?", identificador,
                    null, null, null);

            if(cursor.moveToFirst()){
                Vendas vendas = new Vendas();
                vendas.setCodProduto(cursor.getInt(0));
                vendas.setProduto(cursor.getString(1));
                vendas.setQtde(cursor.getInt(2));
                vendas.setValor(cursor.getInt(3));
                vendas.setVendedor(cursor.getString(4));
                vendas.setDataVenda(cursor.getString(5));
                vendas.setCliente(cursor.getString(6));
                vendas.setCpf(cursor.getString(7));

                return vendas;
            }

        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: VendasDao.getById() "+ex.getMessage());
        }
        return null;
    }
}
